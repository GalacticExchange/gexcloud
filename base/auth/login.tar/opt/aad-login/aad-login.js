// Configuration parameters
var directory = 'bdoaad.onmicrosoft.com';
var clientid  = '3750e216-fba0-49fb-9fa1-9ba204d04139';


console.log(process.argv[4]);
process.exit(1);

if (!directory || !clientid) {
  console.log('You need to provide your directory and client ID');
  process.exit(1);
}

var username = process.argv[2];
var password = process.argv[3];

if (username && password) {
  request = {
    tenant : directory,
    authorityHostUrl : 'https://login.windows.net',
    clientId : clientid,
    username : username + '@' + directory,
    password : password
  };

  var adal = require('adal-node');
  var AuthenticationContext = adal.AuthenticationContext;
  var authorityUrl = request.authorityHostUrl + '/' + request.tenant;
  var resource = '00000002-0000-0000-c000-000000000000';
  var context = new AuthenticationContext(authorityUrl);

  context.acquireTokenWithUsernamePassword(resource, request.username, request.password, request.clientId, function(err, tokenResponse) {
    if (err) { // fail
        console.log(tokenResponse);
        process.exit(1);
    } else {
        console.log(tokenResponse);
        process.exit(0);
    }
  });
} else {
  console.log('No username/password provided');
  process.exit(1);
}

