-- phpMyAdmin SQL Dump
-- version 4.4.13.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 07, 2016 at 02:03 PM
-- Server version: 5.6.31-0ubuntu0.15.10.1
-- PHP Version: 5.6.11-1ubuntu3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gex_logs`
--

-- --------------------------------------------------------

--
-- Table structure for table `log_debug`
--

DROP TABLE IF EXISTS `log_debug`;
CREATE TABLE IF NOT EXISTS `log_debug` (
  `id` bigint(20) NOT NULL,
  `source_id` int(11) DEFAULT NULL,
  `type_id` int(11) NOT NULL,
  `subtype_id` int(11) DEFAULT NULL,
  `level` tinyint(4) NOT NULL DEFAULT '1',
  `user_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `cluster_id` int(11) DEFAULT NULL,
  `node_id` int(11) DEFAULT NULL,
  `instance_id` int(11) DEFAULT NULL,
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `visible_client` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `log_sources`
--

DROP TABLE IF EXISTS `log_sources`;
CREATE TABLE IF NOT EXISTS `log_sources` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `visible_client` tinyint(1) NOT NULL DEFAULT '0',
  `need_notify` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `log_sources`
--

INSERT INTO `log_sources` (`id`, `parent_id`, `name`, `title`, `description`, `enabled`, `visible_client`, `need_notify`) VALUES
(1, NULL, 'app', 'Application', NULL, 1, 0, 0),
(2, 0, 'node', 'Node', NULL, 1, 0, 0),
(3, 0, 'server', 'Server', NULL, 1, 0, 0),
(4, NULL, 'user_action', 'User action', NULL, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `log_system`
--

DROP TABLE IF EXISTS `log_system`;
CREATE TABLE IF NOT EXISTS `log_system` (
  `id` bigint(20) NOT NULL,
  `source_id` int(11) DEFAULT NULL,
  `type_id` int(11) NOT NULL,
  `subtype_id` int(11) DEFAULT NULL,
  `level` tinyint(4) NOT NULL DEFAULT '1',
  `user_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `cluster_id` int(11) DEFAULT NULL,
  `node_id` int(11) DEFAULT NULL,
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `visible_client` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `log_types`
--

DROP TABLE IF EXISTS `log_types`;
CREATE TABLE IF NOT EXISTS `log_types` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `visible_client` tinyint(1) NOT NULL DEFAULT '0',
  `need_notify` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `log_types`
--

INSERT INTO `log_types` (`id`, `parent_id`, `name`, `title`, `description`, `enabled`, `visible_client`, `need_notify`) VALUES
(1, NULL, 'api_request_start', 'api_request_start', NULL, 1, 0, 0),
(2, NULL, 'response_error', 'response_error', NULL, 1, 0, 0),
(3, NULL, 'user_created', 'user_created', '', 1, 1, 0),
(4, NULL, 'user_create_error', 'user_create_error', NULL, 1, 0, 0),
(5, NULL, 'debug', 'debug', NULL, 1, 0, 0),
(6, NULL, 'cluster_create_error', 'cluster_create_error', NULL, 1, 0, 0),
(7, NULL, 'cluster_created', 'cluster_created', '', 1, 1, 0),
(8, NULL, 'ansible_cluster_create_start', 'ansible_cluster_create_start', NULL, 1, 0, 0),
(9, NULL, 'ansible_start', 'ansible_start', NULL, 1, 0, 0),
(10, NULL, 'ansible_error', 'ansible_error', NULL, 1, 0, 0),
(11, NULL, 'cluster_state_changed', 'cluster_state_changed', NULL, 1, 0, 0),
(12, NULL, 'cluster_install_error', 'cluster_install_error', NULL, 1, 0, 0),
(13, NULL, 'track', 'track', NULL, 1, 0, 0),
(14, NULL, 'notify', 'notify', NULL, 1, 0, 0),
(15, NULL, 'exception', 'exception', NULL, 1, 0, 0),
(16, NULL, 'ansible_node_create_start', 'ansible_node_create_start', NULL, 1, 0, 0),
(17, NULL, 'node_install_error', 'node_install_error', NULL, 1, 0, 0),
(18, NULL, 'user_verified', 'user_verified', '', 1, 1, 0),
(19, NULL, 'ansible_ok', 'ansible_ok', NULL, 1, 0, 0),
(20, NULL, 'cluster_installed', 'cluster_installed', '', 1, 1, 0),
(21, NULL, 'node_installed', 'node_installed', NULL, 1, 0, 0),
(22, NULL, 'notify_node', 'notify_node', '', 1, 1, 0),
(23, NULL, 'node_state_changed', 'node_state_changed', NULL, 1, 0, 0),
(24, NULL, 'debug_node_control', 'debug_node_control', NULL, 1, 0, 0),
(25, NULL, 'debug_delete_node', 'debug_delete_node', NULL, 1, 0, 0),
(26, NULL, 'node_control_command_sent', 'node_control_command_sent', '', 1, 1, 0),
(27, NULL, 'shell_error', 'shell_error', NULL, 1, 0, 0),
(28, NULL, 'vagrant_halt', 'vagrant_halt', NULL, 1, 0, 0),
(29, NULL, 'vagrant_destroy', 'vagrant_destroy', NULL, 1, 0, 0),
(30, NULL, 'node_uninstall_remove_config_files', 'node_uninstall_remove_config_files', NULL, 1, 0, 0),
(31, NULL, 'ansible_update_container_route', 'ansible_update_container_route', NULL, 1, 0, 0),
(32, NULL, 'vagrant_up', 'vagrant_up', NULL, 1, 0, 0),
(33, NULL, 'node_uninstall_stop_box', 'node_uninstall_stop_box', NULL, 1, 0, 0),
(34, NULL, 'vagrant_reload_halt', 'vagrant_reload_halt', NULL, 1, 0, 0),
(35, NULL, 'vagrant_reload_up', 'vagrant_reload_up', NULL, 1, 0, 0),
(36, NULL, 'login', 'login', NULL, 1, 0, 0),
(37, NULL, 'node_install', 'node_install', NULL, 1, 0, 0),
(38, NULL, 'lock_error', 'lock_error', NULL, 1, 0, 0),
(39, NULL, 'login_error', 'login_error', NULL, 1, 0, 0),
(40, NULL, 'user_password_update_error', 'user_password_update_error', NULL, 1, 0, 0),
(41, NULL, 'user_password_updated', 'user_password_updated', NULL, 1, 0, 0),
(42, NULL, 'application_create_error', 'application_create_error', NULL, 1, 0, 0),
(43, NULL, 'application_create', 'application_create', NULL, 1, 0, 0),
(44, NULL, 'user_verify_error', 'user_verify_error', NULL, 1, 0, 0),
(45, NULL, 'logout', 'logout', NULL, 1, 0, 0),
(46, NULL, 'node_agent_info_error', 'node_agent_info_error', NULL, 1, 0, 0),
(47, NULL, 'box', 'box', NULL, 1, 0, 0),
(48, NULL, 'node_uninstall', 'node_uninstall', NULL, 1, 0, 0),
(49, NULL, 'debug_delete_node_containers', 'debug_delete_node_containers', NULL, 1, 0, 0),
(50, NULL, 'node_reinstall', 'node_reinstall', NULL, 1, 0, 0),
(51, NULL, 'error', 'error', NULL, 1, 0, 0),
(52, NULL, 'node_uninstall_force', 'node_uninstall_force', NULL, 1, 0, 0),
(53, NULL, 'node_uninstall_error', 'node_uninstall_error', NULL, 1, 0, 0),
(54, NULL, 'check_virtualization', 'check_virtualization', NULL, 1, 0, 0),
(55, NULL, 'node_uninstall_remove_box', 'node_uninstall_remove_box', NULL, 1, 0, 0),
(56, NULL, 'debug_auth_access_cluster', 'debug_auth_access_cluster', NULL, 1, 0, 0),
(57, NULL, 'container_state_changed', 'container_state_changed', NULL, 1, 0, 0),
(58, NULL, 'rabbit', 'rabbit', NULL, 1, 0, 0),
(59, NULL, 'provision_install', 'provision_install', NULL, 1, 0, 0),
(60, NULL, 'check_gexd', 'check_gexd', NULL, 1, 0, 0),
(61, NULL, 'parse_error', 'parse_error', NULL, 1, 0, 0),
(62, NULL, 'share_create_error', 'share_create_error', NULL, 1, 0, 0),
(63, NULL, 'debug_provision_chef', 'debug_provision_chef', NULL, 1, 0, 0),
(64, NULL, 'general_error', 'general_error', NULL, 1, 0, 0),
(65, NULL, 'user_create', 'user_create', NULL, 1, 0, 0),
(66, NULL, 'vagrant', 'vagrant', NULL, 1, 0, 0),
(67, NULL, 'node_control_command_send_error', 'node_control_command_send_error', NULL, 1, 0, 0),
(68, NULL, 'debug_debug', 'debug_debug', NULL, 1, 0, 0),
(69, NULL, 'debug_provision', 'debug_provision', NULL, 1, 0, 0),
(70, NULL, 'debug_install_app', 'debug_install_app', NULL, 1, 0, 0),
(71, NULL, 'app_install_error', 'app_install_error', NULL, 1, 0, 0),
(72, NULL, 'vbox_machine_folder', 'vbox_machine_folder', NULL, 1, 0, 0),
(73, NULL, 'debug_application_install', 'debug_application_install', NULL, 1, 0, 0),
(74, NULL, 'debug_rabbit', 'debug_rabbit', NULL, 1, 0, 0),
(75, NULL, 'provision_run', 'provision_run', NULL, 1, 0, 0),
(76, NULL, 'notify_application', 'notify_application', NULL, 1, 0, 0),
(77, NULL, 'application_install_error', 'application_install_error', NULL, 1, 0, 0),
(78, NULL, 'auth_agent_token_invalid', 'auth_agent_token_invalid', NULL, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `log_user_actions`
--

DROP TABLE IF EXISTS `log_user_actions`;
CREATE TABLE IF NOT EXISTS `log_user_actions` (
  `id` int(11) NOT NULL,
  `log_user_action_type_id` int(11) NOT NULL DEFAULT '1',
  `user_id` int(11) DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `log_user_action_types`
--

DROP TABLE IF EXISTS `log_user_action_types`;
CREATE TABLE IF NOT EXISTS `log_user_action_types` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `log_debug`
--
ALTER TABLE `log_debug`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `log_type_id` (`type_id`),
  ADD KEY `cluster_id` (`cluster_id`),
  ADD KEY `created_at` (`created_at`),
  ADD KEY `team_id` (`team_id`),
  ADD KEY `node_id` (`node_id`),
  ADD KEY `source_id` (`source_id`),
  ADD KEY `instance_id` (`instance_id`);

--
-- Indexes for table `log_sources`
--
ALTER TABLE `log_sources`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `log_system`
--
ALTER TABLE `log_system`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `log_type_id` (`type_id`),
  ADD KEY `cluster_id` (`cluster_id`),
  ADD KEY `created_at` (`created_at`),
  ADD KEY `team_id` (`team_id`),
  ADD KEY `source_id` (`source_id`);

--
-- Indexes for table `log_types`
--
ALTER TABLE `log_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `log_user_actions`
--
ALTER TABLE `log_user_actions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `created_at` (`created_at`),
  ADD KEY `log_user_action_type_id` (`log_user_action_type_id`);

--
-- Indexes for table `log_user_action_types`
--
ALTER TABLE `log_user_action_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `log_debug`
--
ALTER TABLE `log_debug`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `log_sources`
--
ALTER TABLE `log_sources`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `log_system`
--
ALTER TABLE `log_system`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `log_types`
--
ALTER TABLE `log_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=79;
--
-- AUTO_INCREMENT for table `log_user_actions`
--
ALTER TABLE `log_user_actions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `log_user_action_types`
--
ALTER TABLE `log_user_action_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
